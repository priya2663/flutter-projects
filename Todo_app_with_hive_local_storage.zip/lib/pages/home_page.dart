import 'package:flutter/material.dart';
import 'package:routing/utils/todo_list.dart';
import 'package:shared_preferences/shared_preferences.dart';

class Homepage extends StatefulWidget {
  Homepage({Key? key}) : super(key: key);

  @override
  State<Homepage> createState() => _HomepageState();
}

class _HomepageState extends State<Homepage> {
  final _controller = TextEditingController();

  List<String> Todolist = [];

  void checkBoxChanged(int index) {
    setState(() {
      final parts = Todolist[index].split('|');
      final task = parts[0];
      final completed = parts[1] == 'true';
      Todolist[index] = "$task|${!completed}";
    });
    saveTodos();
  }

  void saveNewTask() {
    if (_controller.text.trim().isEmpty) return;

    setState(() {
      Todolist.add(
          "${_controller.text}|false"); // save as string "task|completed"
      _controller.clear();
    });

    saveTodos(); // save in storage
  }

  void deleteTask(int index) {
    setState(() {
      Todolist.removeAt(index);
    });
    saveTodos();
  }

  @override
  void initState() {
    super.initState();
    loadTodos();
  }

  Future<void> loadTodos() async {
    final prefs = await SharedPreferences.getInstance();
    List<String>? savedTodos = prefs.getStringList('TODOLIST');

    if (savedTodos != null) {
      Todolist = savedTodos;
      setState(() {}); // UI refresh
    }
  }

  Future<void> saveTodos() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList('TODOLIST', Todolist);
  }

  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.deepPurple.shade300,
      appBar: AppBar(
        title: Center(child: Text("Simple To-Do")),
        backgroundColor: Colors.deepPurple,
        foregroundColor: Colors.white,
      ),
      body: ListView.builder(
        itemCount: Todolist.length,
        itemBuilder: (context, index) {
          final parts = Todolist[index].split('|');

          return Todo_list(
            taskName: parts[0],
            taskCompleted: parts[1] == 'true',
            onChanged: (value) => checkBoxChanged(index),
            deletefunction: (context) => deleteTask(index),
          );
        },
      ),
      floatingActionButton: Row(
        children: [
          Expanded(
              child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: TextField(
              controller: _controller,
              decoration: InputDecoration(
                  filled: true,
                  fillColor: Colors.deepPurple.shade200,
                  hintText: "Add a new todo items",
                  enabledBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: Colors.deepPurple),
                      borderRadius: BorderRadius.circular(15)),
                  focusedBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: Colors.deepPurple),
                      borderRadius: BorderRadius.circular(15))),
            ),
          )),
          FloatingActionButton(
            onPressed: saveNewTask,
            child: Icon(
              Icons.add,
            ),
          ),
        ],
      ),
    );
  }
}
