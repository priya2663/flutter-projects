package com.example.routing

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
