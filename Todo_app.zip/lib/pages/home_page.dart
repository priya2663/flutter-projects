import 'package:flutter/material.dart';
import 'package:routing/utils/todo_list.dart';

class Homepage extends StatefulWidget {
  Homepage({Key? key}) : super(key: key);

  @override
  State<Homepage> createState() => _HomepageState();
}

class _HomepageState extends State<Homepage> {
  final _controller = TextEditingController();

  List Todolist = [
    ['drink cofee', false],
    ['wakeup early morning', false],
  ];

  void checkBoxChanged(int index) {
    setState(() {
      Todolist[index][1] = !Todolist[index][1];
    });
  }

  void saveNewTask() {
    setState(() {
      Todolist.add([_controller.text, false]);
      _controller.clear();
    });
  }

  void deleteTask(int index) {
    setState(() {
      Todolist.removeAt(index);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.deepPurple.shade300,
      appBar: AppBar(
        title: Center(child: Text("Simple To-Do")),
        backgroundColor: Colors.deepPurple,
        foregroundColor: Colors.white,
      ),
      body: ListView.builder(
          itemCount: Todolist.length,
          itemBuilder: (context, index) {
            return Todo_list(
              taskName: Todolist[index][0],
              taskCompleted: Todolist[index][1],
              onChanged: (value) => checkBoxChanged(index),
              deletefunction: (context) => deleteTask(index),
            );
          }),
      floatingActionButton: Row(
        children: [
          Expanded(
              child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: TextField(
              controller: _controller,
              decoration: InputDecoration(
                  filled: true,
                  fillColor: Colors.deepPurple.shade200,
                  hintText: "Add a new todo items",
                  enabledBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: Colors.deepPurple),
                      borderRadius: BorderRadius.circular(15)),
                  focusedBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: Colors.deepPurple),
                      borderRadius: BorderRadius.circular(15))),
            ),
          )),
          FloatingActionButton(
            onPressed: saveNewTask,
            child: Icon(
              Icons.add,
            ),
          ),
        ],
      ),
    );
  }
}
